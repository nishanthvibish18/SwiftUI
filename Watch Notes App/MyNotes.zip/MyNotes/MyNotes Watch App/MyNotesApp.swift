//
//  MyNotesApp.swift
//  MyNotes Watch App
//
//  Created by Nishanth Vibi on 27/07/23.
//

import SwiftUI

@main
struct MyNotes_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
